from random import choice, randint
from string import printable
from typing import List



def get_random_character():
    return choice(printable)


def create_test_case() -> str:
    length = randint(0, 10)
    random_string = ''.join(get_random_character() for _ in range(length))
    return random_string



def create_individual() -> List[str]:
    length = randint(0, 15)
    return [create_test_case() for _ in range(length)]


def create_population(population_size) -> List[List[str]]:

    return [create_individual() for _ in range(population_size)]

print(create_population(7))