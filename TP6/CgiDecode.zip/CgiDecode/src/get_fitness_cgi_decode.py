from typing import List
import sys
sys.path.append("/home/Estudiante/Escritorio/CgiDecode")
from src.evaluate_condition import *
from src.cgi_decode_instrumented import cgi_decode_instrumented

def get_fitness_cgi_decode(test_suite: List[str]) -> float:
    # Borro la información de branch coverage de ejecuciones anteriores
    # Recuerden que los diccionarios true_distances y false_distances son globales
    clear_maps()

    fitness = 0
    # TODO: COMPLETAR
    for test_case in test_suite:
        try:
            cgi_decode_instrumented(test_case)
        finally:
            continue
    for k in distances_true.values():
        fitness+=k/(k+1)
    for k in distances_false.values():
        fitness+=k/(k+1)
    fitness += (5-len(distances_true)) * 2

    return fitness


