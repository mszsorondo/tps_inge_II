#!./venv/bin/python
import unittest
from src.cgi_decode import cgi_decode


class TestCgiDecode(unittest.TestCase):
    
    def test1(self):
        s = "+%abb"
        self.assertEqual(cgi_decode(s),f" {chr(171)}b")
    def testInvalid1(self):
        s = "%qb"
        with self.assertRaises(ValueError) as cm:
            cgi_decode(s)
    def testInvalid2(self):
        s = "%bq"
        with self.assertRaises(ValueError) as cm:
            cgi_decode(s)