from random import randint
from typing import List, Tuple


def crossover(parent1: List[str], parent2: List[str]) -> Tuple[List[str], List[str]]:
    offspring1 = None
    offspring2 = None

    minlen = min(len(parent1), len(parent2))
    cut_idx = randint(0,minlen)
    offspring1 = parent1[:cut_idx] + parent2[cut_idx:]
    offspring2 = parent2[:cut_idx] + parent1[cut_idx:]
    return offspring1, offspring2
