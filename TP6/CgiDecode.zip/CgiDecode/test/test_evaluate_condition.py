#!./venv/bin/python
import unittest
from src.evaluate_condition import evaluate_condition


class TestEvaluateCondition(unittest.TestCase):
    
    def test1(self):
        # TODO COMPLETAR
        self.assertFalse(evaluate_condition(1, "Eq", 10, 20))
    def test2(self):
        # TODO COMPLETAR
        self.assertTrue(evaluate_condition(1, "Eq", 20, 20))
    def test3(self):
        # TODO COMPLETAR
        self.assertTrue(evaluate_condition(1, "Le", 10, 20))
    def test4(self):
        # TODO COMPLETAR
        self.assertTrue(evaluate_condition(1, "Ge", 30, 20))
    def test_eq_with_ints(self):
        self.assertTrue(evaluate_condition(1, "Eq", 5, 5))
        self.assertFalse(evaluate_condition(1, "Eq", 5, 6))

    def test_ne_with_ints(self):
        self.assertTrue(evaluate_condition(2, "Ne", 5, 6))
        self.assertFalse(evaluate_condition(2, "Ne", 5, 5))

    def test_le_with_ints(self):
        self.assertTrue(evaluate_condition(3, "Le", 5, 6))
        self.assertTrue(evaluate_condition(3, "Le", 5, 5))
        self.assertFalse(evaluate_condition(3, "Le", 6, 5))

    def test_lt_with_ints(self):
        self.assertTrue(evaluate_condition(4, "Lt", 5, 6))
        self.assertFalse(evaluate_condition(4, "Lt", 5, 5))
        self.assertFalse(evaluate_condition(4, "Lt", 6, 5))

    def test_ge_with_ints(self):
        self.assertTrue(evaluate_condition(5, "Ge", 6, 5))
        self.assertTrue(evaluate_condition(5, "Ge", 5, 5))
        self.assertFalse(evaluate_condition(5, "Ge", 5, 6))

    def test_gt_with_ints(self):
        self.assertTrue(evaluate_condition(6, "Gt", 6, 5))
        self.assertFalse(evaluate_condition(6, "Gt", 5, 5))
        self.assertFalse(evaluate_condition(6, "Gt", 6, 7))

    def test_in_with_dict(self):
        self.assertTrue(evaluate_condition(7, "In", 'a', {'a': 1, 'b': 2})) 
        self.assertFalse(evaluate_condition(7, "In", 'n', {'a': 1, 'b': 2}))  

    def test_str_comparison(self):
        self.assertTrue(evaluate_condition(8, "Eq", 'a', 'a'))
        self.assertFalse(evaluate_condition(8, "Eq", 'a', 'b'))
