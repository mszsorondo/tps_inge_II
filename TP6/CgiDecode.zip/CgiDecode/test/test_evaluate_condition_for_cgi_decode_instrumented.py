#!./venv/bin/python
import unittest
from src.cgi_decode import cgi_decode
from src.cgi_decode_instrumented import cgi_decode_instrumented
from src.evaluate_condition import clear_maps, get_true_distance, get_false_distance


class TestEvaluateConditionForCgiDecodeInstrumented(unittest.TestCase):
    def test1(self):
        """
        Ejecutando cgi_decode_instrumented(“Hello+World”) retorna “Hello World”
        El diccionario distances_true queda {1: 0, 2: 0, 3: 35}
        El diccionario distances_false queda {1: 0, 2: 0, 3: 0}
        """
        clear_maps()
        result = cgi_decode_instrumented("Hello+World")
        
        self.assertEqual(result, "Hello World")

        self.assertEqual(get_true_distance(1), 0)
        self.assertEqual(get_true_distance(2), 0)
        self.assertEqual(get_true_distance(3), 35)


        self.assertEqual(get_false_distance(1), 0)
        self.assertEqual(get_false_distance(2), 0)
        self.assertEqual(get_false_distance(3), 0)
    def test2(self):
        """
        
        """
        clear_maps()
        result = cgi_decode_instrumented("a%ab+")
        v = chr(10 * 16 + 11)
        self.assertEqual(result, f"a{v} ")

        self.assertEqual(get_true_distance(1), 0)
        self.assertEqual(get_true_distance(2), 0)
        self.assertEqual(get_true_distance(3), 0)
        self.assertEqual(get_true_distance(4), 0)
        self.assertEqual(get_true_distance(5), 0)

        self.assertEqual(get_false_distance(1), 0)
        self.assertEqual(get_false_distance(2), 0)
        self.assertEqual(get_false_distance(3), 0)

        self.assertEqual(get_true_distance(1), 0)
        self.assertEqual(get_true_distance(2), 0)
        self.assertEqual(get_true_distance(3), 0)
        self.assertEqual(get_true_distance(4), 0)
        self.assertEqual(get_true_distance(5), 0)

        self.assertEqual(get_false_distance(1), 0)
        self.assertEqual(get_false_distance(2), 0)
        self.assertEqual(get_false_distance(3), 0)

        self.assertEqual(get_false_distance(4), 1)
        self.assertEqual(get_false_distance(5), 1)
        self.assertEqual(get_false_distance(4), 1)
        self.assertEqual(get_false_distance(5), 1)
    def test3(self):
        """
        
        """
        clear_maps()
        with self.assertRaises(ValueError) as cm:
            cgi_decode_instrumented("a%qab+")
    def test4(self):
        """
        
        """
        clear_maps()
        with self.assertRaises(ValueError) as cm:
            cgi_decode_instrumented("a%aqb+")