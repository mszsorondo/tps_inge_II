from random import choice, randint
from typing import List

from src.create_population import create_test_case, get_random_character


def add_character(test_case: str) -> str:
    idx = randint(0,len(test_case)-1)
    res = test_case
    return res[:idx] + str(get_random_character()) + res[idx:]


def remove_character(test_case: str) -> str:
    idx = randint(0,len(test_case)-1)
    return test_case[:idx] + test_case[idx+1:]


def modify_character(test_case: str) -> str:
    idx = randint(0,len(test_case)-1)
    res = test_case
    res[idx] = get_random_character()
    return res


def add_test_case(individual: List[str]) -> List[str]:
    # TODO: COMPLETAR
    res = individual.append(create_test_case())
    return res


def remove_test_case(individual: List[str]) -> List[str]:
    # TODO: COMPLETAR
    res = individual
    element_to_remove = choice(res)
    res.remove(element_to_remove)
    return res


def modify_test_case(individual: List[str]) -> List[str]:
    # TODO: COMPLETAR
    i = randint(0,len(individual)-1)
    test_original = individual[i]
    
    options = []
    if(len(test_original)>0):
        options = ["remove", "mod"]
    
    if len(test_original)<10:
        options.append("add")
    opt_selected = choice(options)
    if opt_selected == "remove":
        individual[i] = remove_character(test_original)
    elif opt_selected == "mod":
        individual[i] = modify_character(test_original)
    elif opt_selected == "add":
        individual[i] = add_character(test_original)

    return individual


def mutate(individual: List[str]) -> List[str]:
    # TODO: COMPLETAR
    options = []
    res = None
    if len(individual):
        options = ["delTestCase","modTestCase"]
    if(len(individual)<15):
        options.append("newTestCase")
    
    opt_selected = choice(options)
    if opt_selected == "newTestCase":
        res = add_test_case(individual)
    elif opt_selected == "delTestCase":
        res = remove_test_case(individual)
    elif opt_selected == "modTestCase":
        res = modify_test_case(individual)

    return res

