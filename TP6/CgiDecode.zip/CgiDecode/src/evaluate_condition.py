import sys
from typing import Dict, Union

# Inicializar mappings globales
distances_true: Dict[int, int] = {}
distances_false: Dict[int, int] = {}


def update_maps(condition_num: int, d_true: int, d_false: int):
    global distances_true, distances_false

    if condition_num in distances_true.keys():
        distances_true[condition_num] = min(
            distances_true[condition_num], d_true)
    else:
        distances_true[condition_num] = d_true

    if condition_num in distances_false.keys():
        distances_false[condition_num] = min(
            distances_false[condition_num], d_false)
    else:
        distances_false[condition_num] = d_false


def clear_maps():
    global distances_true, distances_false
    distances_true.clear()
    distances_false.clear()


def get_true_distance(condition_num: int) -> Union[int, None]:
    global distances_true
    if condition_num in distances_true.keys():
        return distances_true[condition_num]
    else:
        return None


def get_false_distance(condition_num: int) -> Union[int, None]:
    global distances_false
    if condition_num in distances_false.keys():
        return distances_false[condition_num]
    else:
        return None


def has_reached_condition(condition_num: int) -> bool:
    global distances_true, distances_false
    return condition_num in distances_true.keys() or condition_num in distances_false.keys()


def evaluate_condition(condition_num: int, op: str, lhs: Union[str, Dict], rhs: Union[str, Dict]) -> bool:
    if isinstance(rhs, str):
        lhs = ord(lhs)
        rhs = ord(rhs)

    # Ahora lhs o rhs pueden ser o int o dict

    K = 1
    dist = 0
    dist_t = 0
    dist_f = 0
    
    # Caso son int
    if op=="Eq":
        dist_t = abs(lhs-rhs)
        dist_f = int(dist_t == 0)
    
    elif op=="Ne":
        dist_f = abs(lhs-rhs)
        dist_t = int(dist_f == 0)
    elif op=="Le":
        if (lhs<=rhs):
            dist_f = abs(lhs-rhs)+ K
            dist_t = 0
        else:
            dist_f = 0
            dist_t =abs(lhs - rhs) 

    elif op=="Lt":
        if (lhs<rhs):
            dist_f = abs(lhs-rhs)
            dist_t = 0
        else:
            dist_f = 0
            dist_t =abs(lhs - rhs) + K

    elif op=="Ge":
        if (lhs>=rhs):
            dist_f = abs(lhs-rhs)+ K
            dist_t = 0
        else:
            dist_f = 0
            dist_t =abs(lhs - rhs) 

    elif op=="Gt":
        if (lhs>rhs):
            dist_f = abs(lhs-rhs)
            dist_t = 0
        else:
            dist_f = 0
            dist_t =abs(lhs - rhs) + K


    # Caso son dict
    elif op=="In" and isinstance(rhs, Dict):
        dist_t = sys.maxsize
        if rhs.keys():
            dist_t = min([abs(ord(lhs) - ord(k)) for k in rhs.keys()])
        dist_f = int(dist_t==0)
        
    update_maps(condition_num,dist_t, dist_f)
    

    #true_distance = get_true_distance(condition_num)
    #false_distance = get_false_distance(condition_num)
    
    return dist_t==0
